

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>


<?php

/*<img id=d1 src="dado1.jpg">
    <img id=d2 src="dado2.jpg">
    <img id=d3 src="dado3.jpg">
    <img id=d4 src="dado4.jpg">
    <img id=d5 src="dado5.jpg">
    <img id=d6 src="dado6.jpg">
    */

   $dados = [1 => [1,2,3,4,5,6],2=>[1,2,3,4,5,6],3=>[1,2,3,4,5,6],4=>[1,2,3,4,5,6],5=>[1,2,3,4,5,6],6=>[1,2,3,4,5,6]];
   print_r($dados)

   foreach($dados as $clave => $num){

   }


   rand(1,6)
   
?>













?php

/*Escribir un programa que genere en cada ejecución una tirada de Yahtzee! indicando un resumen de las jugadas posibles y 
cuál es la recomendada.

El juego de Yahtzee! emplea 5 dados de 6 caras y las combinaciones posibles son:

3 de una clase: Debes obtener tres dados iguales. Sumas la puntuación de todos esos dados.
4 de una clase: Debes obtener cuatro dados iguales. Sumas la puntuación de todos los dados.
Full: Debes obtener tres dados de una clase y dos de otra. Por ejemplo, tres de 1 y dos de 5. Esta jugada vale 25 puntos.
Escalera pequeña: Debes obtener cuatro dados consecutivos. Por ejemplo: 1, 2, 3 y 4 o 3, 4, 5 y 6. Esta jugada vale 30 puntos.
Escalera grande: Debes obtener cinco dados consecutivos. Por ejemplo: 1, 2, 3, 4 y 5 o 2, 3, 4, 5 y 6. Esta jugada vale 40 puntos.
Yahtzee: Debes obtener cinco dados iguales de la misma clase. Esta jugada vale 50 puntos.
*/
?>

