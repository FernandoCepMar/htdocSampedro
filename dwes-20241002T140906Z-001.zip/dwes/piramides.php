
<?php 

// 7. Escribir un programa que pinte por pantalla una pirámide rellena a base de asteriscos.
// La base de la pirámide debe estar formada por 9 asteriscos.

$asteriscos = "";
$espacios = "";
//el primer bucle for crea cada fila de la pirámide
for($i=1;$i<=9;$i++){
    for($y=1;$y <= $i ; $y++){
        //para cada fila,para cada vuelta del for anterior se guarda el 
        //mismo numero de * que el número de la fila en la que se encuentre $i
        //de esta manera, si se esta en la fila 3, el string tendrá 3 asteriscos 
        $asteriscos .= " * ";
    }
    for($e=9;$e >= $i ; $e--){
        $espacios .= " ";
    }/*es un bucle que va al revés, el numero
    de la fila es inversamente proporcional al numero de espacios */
    echo "<pre>". $espacios.$asteriscos.$espacios ."</pre>";
    /*el navegador cuando le llega un echo con un string con muchos espacios,
    los colapsa todos a un solo, de manera que para mantener los espacios en la salida
    existe la etiqueta <pre> que mantiene el formato de cómo se escribe dentro de ella.

    Además, como <pre> es una etiqueta de bloque, cada vez que se imprime la fila de la
    piramide, no hace falta hacer echo "<br>" en el for que cambia de fila a fila ya que
    el propio <pre> hace el salto de línea
    */
    $asteriscos="";
    $espacios= "";
    //reinicio,vacío los strings cada vez que se cambia de fila 
}

//es lo mismo pero variando los valores límite
$asteriscos = "";
$espacios = "";
for($i=0;$i<=9;$i++){
    for($y=0;$y < $i ; $y++){
        $asteriscos .= " * ";
    }
    for($e=9;$e > $i ; $e--){
        $espacios .= " ";
    }
    echo "<pre>". $espacios.$asteriscos.$espacios ."</pre>";
    $asteriscos="";
    $espacios= "";
}
?>

<?php 
echo "<br>";

// 8. Repetir el ejercicio anterior, pero esta vez la pirámide estará hueca (se debe ver
// únicamente el contorno hecho con asteriscos).

$asteriscos = "";
$espacios = "";
for($i=1;$i<=9;$i++){
    for($y=1;$y <= $i ; $y++){
        $asteriscos .= " * ";
    }
    for($e=9;$e >= $i ; $e--){
        $espacios .= " ";
    }
    /*Como el string de asteriscos tiene espacios entre ellos,
    uso la funcion trim que al igual que en java,elimina los espacios a ambos lados
    trim no modifica el array que se le introduce como parámetro sino que 
    retorna uno nuevo, por lo que lo igualo al string original */
    $asteriscos=trim($asteriscos);
    if(strlen($asteriscos) - 2 >=1 and $i != 9){
        /*solo se mete en el for si no es la ultima fila y si
        tiene asteriscos en medio a parte de los del contorno,por ej. : 3 o más ya que 3-2 >=1*/
        for($s=1; $s < strlen($asteriscos) -1; $s++){
            $asteriscos[$s] = " ";
        }/*se recorre el string menos la primera y la ultima posición que serian los asteriscos del contorno
         y se sustituye por espacios el resto */
    }

    echo "<pre>". $espacios.$asteriscos.$espacios ."</pre>";

    $asteriscos="";
    $espacios= "";
}

?>

<?php

// 9. Repetir el ejercicio anterior, pero esta vez la pirámide debe aparecer invertida, esto es,
// con el vértice hacia abajo. 

/*es lo mismo pero las filas ahora en vez de recorrerse de 1 a 9 se recorren de 9 a 1
De esta manera,la primera fila es la que mas asteriscos va a tener ya que 
el bucle for anidado se repite de cada vez mas a cada vez menos.

El for dedicado a sumar los espacios funciona igual, cuanto mayor sea la diferencia
entre el numero de la fila y los asteriscos, mas espacios va a tener */

$asteriscos = "";
$espacios = "";
for($i=9;$i > 0;$i--){
    for($y=1;$y <= $i ; $y++){
        $asteriscos .= " * ";
    }
    for($e=9;$e >= $i ; $e--){
        $espacios .= "x";
    }
    $asteriscos=trim($asteriscos);
    if(strlen($asteriscos) - 2 >=1 and $i != 9){
        for($s=1; $s < strlen($asteriscos) -1; $s++){
            $asteriscos[$s] = " ";
        }
    }
    echo "<pre>". $espacios.$asteriscos.$espacios ."</pre>";

    $asteriscos="";
    $espacios= "";
}
?>



