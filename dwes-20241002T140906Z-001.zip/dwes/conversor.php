<?php

function preguntaTipo($pregunta){
    echo "<script type='text/javascript'> 
        var tipo = prompt($pregunta); 
        document.cookie = 'tipoDeMoneda='+ tipo;
    </script>";
        $tipo = $_COOKIE['tipoDeMoneda'];
        return $tipo;
}

function preguntaCant($pregunta){
    echo "<script type='text/javascript'> 
        var cant = (prompt($pregunta); 
        document.cookie = 'cantidad='+ cant;
    </script>";
        $cant = $_COOKIE['cantidad'];
        return $cant;
}


define("Dolar", 1 );
define("Euro", 1.5);
define("Yen", 0.1);

$tipo = preguntaTipo("Introduce el tipo de moneda");
$cant =(float) preguntaCant("Introduce cantidad");


function conversor($tipo,$cantidad){
    $ret = "";
    $tipo = strtolower($tipo);
if($tipo == "dolar"){
    $euro = $cantidad * Euro;
    $yen = $cantidad * Yen;

    $ret = $cantidad . "dolares son ".$euro . " euros " . $yen . " yenes";

}else if($tipo == "euro"){
    $dol = $cantidad * Dolar;
    $yen = $cantidad * Yen;

    $ret = $cantidad . "euros son ". $dol . " dolares " . $yen . " yenes ";

}else{
    $euro = $cantidad * Euro;
    $dol = $cantidad * Dolar;

    $ret = $cantidad . "yenes son ". $euro . " euros " . $dol . " dolares ";

}
return $ret;
}

$result = conversor($tipo,$cant);

echo $result;

?>
