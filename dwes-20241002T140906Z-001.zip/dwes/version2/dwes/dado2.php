<?php

/*Escribir un programa que genere en cada ejecución una tirada de Yahtzee! indicando un resumen de las jugadas posibles y 
cuál es la recomendada.

El juego de Yahtzee! emplea 5 dados de 6 caras y las combinaciones posibles son:

3 de una clase: Debes obtener tres dados iguales. Sumas la puntuación de todos esos dados.
4 de una clase: Debes obtener cuatro dados iguales. Sumas la puntuación de todos los dados.
Full: Debes obtener tres dados de una clase y dos de otra. Por ejemplo, tres de 1 y dos de 5. Esta jugada vale 25 puntos.
Escalera pequeña: Debes obtener cuatro dados consecutivos. Por ejemplo: 1, 2, 3 y 4 o 3, 4, 5 y 6. Esta jugada vale 30 puntos.
Escalera grande: Debes obtener cinco dados consecutivos. Por ejemplo: 1, 2, 3, 4 y 5 o 2, 3, 4, 5 y 6. Esta jugada vale 40 puntos.
Yahtzee: Debes obtener cinco dados iguales de la misma clase. Esta jugada vale 50 puntos.
*/

$dados=[];
for($i = 0; $i < 5 ; $i++){
    
    $dados[$i]= rand(1,6);
    echo $dados[$i];
    echo '<img src="dado'.$dados[$i].'.jpg">';
}

print_r($dados);

$contador=0;
$repetidos = [0,0,0,0,0,0,0];
for($i= 0; $i < count($dados); $i++){

    for($j=1; $j <= 6 ; $j++){
        if($dados[$i] == $j){
            $contador +=1;
            $repetidos[$j] += $contador;
        }
    }
    $contador=0;

}
print_r($repetidos);

$hayTrio=false;
$puntuacion=0;
for($i = 1; $i < count($repetidos); $i++){
    if($repetidos[$i] == 3){
echo "Has obtenido un trio " ;
$puntuacion = $i * $repetidos[$i];
$hayTrio = true;
echo "Puntuacion :" . $puntuacion;
    }else if($repetidos[$i] == 4){
        echo "Has obtenido un cuatro iguales " ;
        for($i= 0; $i < count($dados);$i++){
            $puntuacion += $dados[$i];
            echo "Puntuacion :" . $puntuacion;
            break;
        }
    }else if( $hayTrio== true and $hayDoble){
        $puntuacion=25;
        break;
    }
}







?>

