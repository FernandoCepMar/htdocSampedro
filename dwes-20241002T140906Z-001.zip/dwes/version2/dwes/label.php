<?php 
echo("<script type='text/javascript'> var answer = prompt('Hola juan') </script>");
echo("<script type='text/javascript'> document.write('<h1>'+ answer + '</h1>') </script>");
?>
<!-- al igual que se puede genearar dinamicamente un html mediante echos de php
 tambien se puede generar dinamicamente html a traves de js -->

<!-- no es necesario un html para imprimir etiquetas html -->
 