<?php

$hola = "  h  ";
echo strlen($hola);

$hola = trim($hola);
echo strlen($hola);
?>