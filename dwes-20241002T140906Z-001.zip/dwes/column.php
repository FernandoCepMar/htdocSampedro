<!-- Control + ç para  -->

<?php

$y = 1;

?>

<html>

<p>H</p>
<p>O</p>
<p>L</p>
<p>A</p>

<style>
    p:nth-child(<?php echo $y ; ?>) {
        background-color: rgb(109, 58, 58);
    }
</style>

</html>